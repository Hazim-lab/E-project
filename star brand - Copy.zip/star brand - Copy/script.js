let slides = document.querySelectorAll('.fade-slide');
let currentIndex = 0;

function showSlide() {
    slides[currentIndex].style.opacity = 0; 
    currentIndex = (currentIndex + 1) % slides.length; 
    slides[currentIndex].style.opacity = 1;
}

slides[currentIndex].style.opacity = 1;

setInterval(showSlide, 2000);
